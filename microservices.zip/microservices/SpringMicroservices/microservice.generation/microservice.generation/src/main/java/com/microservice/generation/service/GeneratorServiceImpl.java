package com.microservice.generation.service;

import com.microservice.generation.entities.Generator;
import com.microservice.generation.persistence.GeneratorRepository;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class GeneratorServiceImpl implements IGeneratorService {


    @Autowired
    private GeneratorRepository generatorRepository;
    @Override
    public List<Generator> findAll() {
        return (List<Generator>) generatorRepository.findAll();
    }

    @Override
    public Generator findById(Long id) {
        return generatorRepository.findById(id).orElseThrow();
    }

    @Override
    public void save(Generator generator) {
        generatorRepository.save(generator);

    }

    @Override
    public List<Generator> findByidGeneracion(Long idGeneracion) {
        return generatorRepository.findAllByGenerator(idGeneracion);
    }
}
