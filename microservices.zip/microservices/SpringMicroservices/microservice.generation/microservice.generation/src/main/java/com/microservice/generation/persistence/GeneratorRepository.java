package com.microservice.generation.persistence;

import com.microservice.generation.entities.Generator;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface GeneratorRepository extends CrudRepository <Generator, Long> {

    @Query("SELECT g FROM Generator g Where g.idGeneracion = :idGeneracion")
    List<Generator> findAllByGenerator (Long idGeneracion);
}
