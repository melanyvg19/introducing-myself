package com.microservice.generation.service;

import com.microservice.generation.entities.Generator;

import java.util.List;

public interface IGeneratorService {

    List<Generator> findAll();

    Generator findById (Long id);

    void save(Generator generator);

    List<Generator> findByidGeneracion(Long idGeneracion);
}
