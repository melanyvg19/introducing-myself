package com.microservice.generation.controller;

import com.microservice.generation.entities.Generator;
import com.microservice.generation.service.IGeneratorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/generator")

public class GeneratorController {

    @Autowired
    private IGeneratorService generatorService;

    @PostMapping("/create")
    @ResponseStatus(HttpStatus.CREATED)
    public void saveGenerator(@RequestBody Generator generator){
        generatorService.save(generator);
    }

}
